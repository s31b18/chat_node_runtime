#! /bin/bash

# Variable define
software_name=chat_node

# Ask for installation
echo "Hey, it is going to install $software_name now"
echo "Are you ready?(y/n)"
read choice
if [ "$choice" = "n" ] ; then
        echo "The installation has been terminated"
        exit 0
fi
echo "OK, lets get start"

# Ask configurations
echo "Please provide the host port of $software_name "
read port
log_file_path="./"

# Write configuration file
cat <<EOF > conf.json
{
    "log_file_path": "${log_file_path}",
    "port": "${port}" 
}
EOF

# Create a Service
echo "Creating a service for $software_name "

# Define the variable require for creating a service
service_name=c_node
c_user="$USER"
start_path="$PWD"

# Write Service File
cat <<EOF >  /etc/systemd/system/${service_name}.service
[Unit]
Description=This is the service of ${software_name}
After=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
User=${c_user}
WorkingDirectory=${start_path}
ExecStart=${start_path}/main

[Install]
WantedBy=multi-user.target
EOF

echo "The service name is $service_name "
echo "The installation has completed"
service $service_name restart
