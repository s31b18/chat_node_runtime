#! /bin/bash
rm -r *.log
rm -r *.log_gin
