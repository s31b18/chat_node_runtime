package main

import (
	mgo "gopkg.in/mgo.v2"
)

var session *mgo.Session
var MONGO_URL = "mongodb://localhost:27017"
var NAME_DB = "chat_node"

func init_mongodDB() {

}

func connectMongod() (*mgo.Session, error) {
	session, err := mgo.Dial(MONGO_URL)
	if err != nil {
		getLogger().log(ERROR, err)
		return nil, err
	}
	return session, nil
}

func getCollection(CollectionName string, dbName string) (*mgo.Collection, *mgo.Session, error) {
	var err error
	session, err = connectMongod()
	if err != nil {
		return nil, session, err
	}
	return session.DB(dbName).C(CollectionName), session, nil
}

func clearCollections(CollectionName string, dbName string) error {
	var err error
	session, err = connectMongod()
	defer session.Close()
	if err != nil {
		return err
	}
	_, err = session.DB(dbName).C(CollectionName).RemoveAll(nil)
	if err != nil {
		return err
	}
	return nil
}
