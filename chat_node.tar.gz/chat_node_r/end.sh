#! /bin/bash
service_name=c_node
sudo service $service_name stop
