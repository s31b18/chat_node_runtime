package main

import (
	"flag"
	"log"
	"math/rand"
	"net/http"
	"os"
	"time"
)

func serveHome(w http.ResponseWriter, r *http.Request) {
	log.Println(r.URL)
	if r.URL.Path != "/" {
		http.Error(w, "Not found", http.StatusNotFound)
		return
	}
	if r.Method != "GET" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	http.ServeFile(w, r, "home.html")
}

func main() {
	rand.Seed(time.Now().UTC().UnixNano())

	// Read the Configuration File
	err := getConfigure().readConfigs()
	if err != nil {
		getLogger().stdPrint(ERROR, "Exit Program")
		os.Exit(3)
	}

	// Test Mongodb Connection
	getLogger().log(TRACK, "Testing Mongodb Connection")
	session, err = connectMongod()
	session.Close()
	if err != nil {
		getLogger().log(ERROR, "Mongodb Connection Test Fail")
		getLogger().log(ERROR, "Exit Program")
		os.Exit(3)
	}
	getLogger().log(TRACK, "Testing Mongodb Success")

	flag.Parse()
	hub := newHub()
	go hub.run()
	http.HandleFunc("/", serveHome)
	http.HandleFunc("/register", registerUserHandler)
	http.HandleFunc("/ws", func(w http.ResponseWriter, r *http.Request) {
		serveWs(hub, w, r)
	})
	err = http.ListenAndServe(":"+configure.config.Port, nil)
	if err != nil {
		getLogger().log(ERROR, err)
	}
}
